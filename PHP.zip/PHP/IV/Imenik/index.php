<!DOCTYPE html>
<html>
	<head>
		<title>Imenik</title>
		<meta charset="utf-8">
		<script src="validacija.js"></script>
	</head>
	<body>
		 <form name="imenik" method="POST" onsubmit="return Validacija()">
				Ime: <input type="text" name="name" id="name"><br>
				Prezime: <input type="text" name="prezime" id="lastname"><br>
				Broj telefon:<input type="text" name="broj" id="number">
				<p id="greska"></p>
				<input type="submit" value="Potvrdi">
		</form>
		
		<?php
			if(isset($_POST["name"])&&isset($_POST["prezime"])&&isset($_POST["broj"]))
			{
				$myfile = fopen("imenik.txt", "a") or die("Unable to open file!");
				$razmak="\n";
				$name= $_POST["name"];
				fwrite($myfile, $name);
				fwrite($myfile,$razmak);
				$lastname = $_POST["prezime"];
				fwrite($myfile, $lastname);
				fwrite($myfile,$razmak);
				$number=$_POST["broj"];
				fwrite($myfile,$number);
				fwrite($myfile,$razmak);
				fclose($myfile);
			}
		?>
		
	</body>
</html>