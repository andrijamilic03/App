function Validacija() {
	
    var name = document.getElementById("name").value;
	var lastname=document.getElementById("lastname").value;
    var number = document.getElementById("number").value;

    if(name == "" || lastname == "" || number == "")
    {
        greska.innerHTML = "Sva polja moraju biti popunjena";
        return false;
    }
	if(!number.match(/^\d+/))
	{
		greska.innerHTML="Morate uneti samo brojeve";
		return false;
	}
if(number.length>10||number.length<10)
	{
		greska.innerHTML="Telefonski broj mora imati 10 cifara";
		return false;
	}
	
    
	
}