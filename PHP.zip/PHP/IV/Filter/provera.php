<?php
session_start();
?>
<!DOCTYPE HTML>  
<html>
<head>
</head>
<body>

<?php  
    if ($_SERVER["REQUEST_METHOD"] == "POST") 
    {
        $name = $_POST["name"];
        $name = filter_var($name, FILTER_SANITIZE_STRING);
        $lname = $_POST["lname"];
        $lname = filter_var($name, FILTER_SANITIZE_STRING);
        $email = $_POST["email"];
        $email = filter_var($email, FILTER_SANITIZE_EMAIL);
        $website = $_POST["website"];
        $website = filter_var($website, FILTER_SANITIZE_URL);
        if($name == "")
        {
            echo "Obavezan unos imena";
        }
        if($lname == "")
        {
            echo "Obavezan unos prezimena";
        }
        if (filter_var($email, FILTER_VALIDATE_EMAIL) === false) 
        {
            echo "Pogresan unos E-maila";
        }
        if (filter_var($website, FILTER_VALIDATE_URL) === false)
        {
            echo "URL nije validan";
        }
        $_SESSION["ime"] = $name;
        $_SESSION["prezime"] = $lname;
        $_SESSION["lozinka"] = $_POST["password"];
        if($name != "" && $lname != "")
    }
?>

</body>
</html>