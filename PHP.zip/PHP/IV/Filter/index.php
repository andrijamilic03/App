<!DOCTYPE HTML>  
<html>
<head>
</head>
<body>

    <form method="post" action="provera.php">  
        <label>Ime: <input type="text" name="name"></label>
        <br>
        <label>Prezime: <input type="text" name="lname"></label>
        <br>
        <label>E-mail: <input type="text" name="email"></label>
        <br>
        <label>Website: <input type="text" name="website">  </label>
        <br>
        <label>Lozinka: <input type="password" name="password">  </label>
        <button type="submit">Submit</button>   
    
    </form>

</body>
</html>