<?php 
	session_start();
	$servername = "localhost";
	$username = "root";
	$password = "";

	$_SESSION["ime_baze"]= $_POST["name"];

	// Create connection
	$_SESSION["conn"] = mysqli_connect($servername, $username, $password);
	
	// Check connection
	if (!$_SESSION["conn"]) 
	{
	  die("Connection failed: " . mysqli_connect_error());
	}

	// Create database
	$sql = "CREATE DATABASE ".$_SESSION["ime_baze"];
	if (mysqli_query($_SESSION["conn"], $sql)) 
	{
	  echo "Baza je kreirana uspešno!";
	} 
	else 
	{
	  echo "Greška pri kreiranju baze:" . mysqli_error($_SESSION["conn"]);
	}
	var_dump($_SESSION["ime_baze"]);

?>
<form action="zadnjastrana.php" method="post">
	Unesi ime tabele: <input type="text" name="imeTabele" id="imeTabele"><br>
	<input type="submit" value="Kreiraj tabelu">
</form>