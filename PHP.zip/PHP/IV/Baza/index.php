<?php 
	session_start();
?>
<html>
	<head>
		<link rel="stylesheet" href="styles.css">
		<title>Baza</title>
	</head>
	<body>
		<form action="tabela.php" method="post">
		Unesi ime baze: <input type="text" name="name" id="name"><br>
		<input type="submit" value="Kreiraj bazu">
	</form>

	</body>
</html>