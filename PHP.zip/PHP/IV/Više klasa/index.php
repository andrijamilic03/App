<!DOCTYPE HTML>  
<html>
	<head>
		<title>Više klasa</title>
		<meta charset="utf-8">
	</head>
	<body>
	
	 <?php
	 class Voce 
	 {
        public $ime;
        public $cena;
        public $kolicina;

        function setIme($ime)
		{
            $this->ime = $ime;
        }

        function setCena($cena)
		{
            $this->cena = $cena;
        }

        function setKolicina($kolicina) 
		{
            $this->kolicina = $kolicina;
        }

        function getIme() 
		{
            return $this->ime;
        }

        function getCena() {
            return $this->cena;
        }

        function getKolicina() 
		{
            return $this->kolicina;
        }

        function Racun() {
            return $this->kolicina*$this->cena;
        }
    }
	if(array_key_exists("potvrda", $_POST)) {
        $x = new Voce();
        $x->setIme($_POST["ime"]);
        $x->setCena($_POST["cena"]);
        $x->setKolicina($_POST["kol"]);
    }
   $apple=new Voce();


	 class Racun 
	 {
		public $cena;
		var $stavke;
		function dodaj_stavku ($ser_br, $kom)
		{

			$this->stavke[$ser_br] += $kom;
		}

		function ukloni_stavku ($ser_br, $kom) 
		{

			if ($this->stavke[$ser_br] > $kom) 
			{

				$this->stavke[$ser_br] -= $kom;

				return true;

			}
			else 
			{
				return false;
			}

		}

	 }
	 $racun = new Racun;
	 
	 
	 class Kupovni_Racun extends Racun 
	 {
		var $kupac;
		function unos_kupca ($ime)
		{
			$this->kupac = $ime;
		}
		
	}
?>

	<form action="index.php" class = "forma" method="post">
        <p>Ime voca</p>
        <input type="text" name="ime" id="ime">
        <p>Cena po komadu</p>
        <input type="number" name="cena" id="cena">
        <p>Kolicina</p>
        <input type="number" name="kol" id="kol"><br><br>
        <input type="submit" name="potvrda" value="Potvrdi"><br><br>
    </form>

	</body>
</html>