<!DOCTYPE HTML>
<html>  
	<body>
		Zdravo <?php echo $_POST ["ime"];?><br>
		Na vašu e-mail adresu <?php echo $_POST ["mejl"];?><br>
		Stići će pitanje <?php echo $_POST ["pitanje"];?><br>
	</body>
</html>