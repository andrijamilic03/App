<!DOCTYPE html>
<html>
<body>
		<?php
			$d1=strtotime("June 4");
			$d2=ceil(($d1-time())/60/60/24);
		?>
					
	<h1>Prijava za posao</h1>
	<form action="prijave.php" method="get">
		Ime: <input type="text" name="ime"><br><br>
		Email: <input type="text" name="email"><br><br>
		<input type="submit" name="submit" value="Posalji">  
	</form>
	<p>Prijava je otvorena jos <?php echo $d2; ?> dana,do 1.juna!</p>
	<?php
		$myfile = fopen("Loremipsum.txt", "r") or die("Unable to open file!");
		while(!feof($myfile)) {
		  echo fgets($myfile) . "<br>";
		}
		fclose($myfile);
	?>
	
	<br><br>
	© 2010-<?php echo date("Y");?>
</body>
</html>
	