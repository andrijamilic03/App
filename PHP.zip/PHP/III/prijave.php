<!DOCTYPE HTML>
<html>  
	<body>
		Zdravo <?php echo $_GET ["ime"];?><br>Hvala na prijavi.<br>
		Javićemo Vam se na Vašu e-mail adresu <?php echo $_GET ["email"];?>
	</body>
</html>
