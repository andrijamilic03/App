<!DOCTYPE html>
<html>
	<body>
	<?php
		$num1=-81;
		$num2=25;
		function ispis($num)
		{
			$av=abs($num);
			$k=sqrt($av);
			echo "Apsolutna vrednost od $num je $av<br>";
			echo "Koren od $av je $k<br>";
		}
		ispis($num1);
		ispis($num2);
		define("crvena","red");
		define("plava","blue");
		for($i=1;$i<$num2;$i++)
		{
			if($i%5==0)
			{
				echo "Brojevi deljivi sa 5:";
				echo "<span style=\"color:".crvena.";\">".$i."</span><br>";
			}
			else if($i%3==0)
			{
				echo "Brojevi deljivi sa 3:";
				echo "<span style=\"color:".plava.";\">".$i."</span><br>";
			}
		}
		$rečenica="Sada počinjemo da učimo PHP skriptni serverski jezik.";
		$r=str_word_count($rečenica);
		echo "U rečenici:$rečenica ,ima $r reči";
	?>
	</body>
</html>
